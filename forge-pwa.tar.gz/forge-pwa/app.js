const STORAGE_KEY = 'forge-v1';

const CORE = [
  { id: 'plank', name: 'Plank', cue: 'Brace core, breathe', baseTarget: 45, unit: 's', baseXp: 8 },
  { id: 'crunches', name: 'Crunches', cue: 'Slow, controlled', baseTarget: 20, unit: 'reps', baseXp: 6 },
  { id: 'legraises', name: 'Leg Raises', cue: 'Lower slowly', baseTarget: 12, unit: 'reps', baseXp: 7 },
  { id: 'twists', name: 'Russian Twists', cue: 'Rotate fully', baseTarget: 16, unit: 'reps', baseXp: 6 },
  { id: 'deadbugs', name: 'Dead Bugs', cue: 'Opposite limbs', baseTarget: 10, unit: 'reps', baseXp: 7 }
];

const DUMBBELLS = [
  { id: 'dbpress', name: 'DB Shoulder Press', cue: 'Elbows at 45°', baseTarget: 10, unit: 'reps', baseXp: 10 },
  { id: 'dbcurl', name: 'DB Bicep Curls', cue: 'No swing', baseTarget: 12, unit: 'reps', baseXp: 8 },
  { id: 'dbrow', name: 'DB Bent Rows', cue: 'Pull to hip', baseTarget: 10, unit: 'reps', baseXp: 9 },
  { id: 'goblet', name: 'Goblet Squat', cue: 'Depth controlled', baseTarget: 12, unit: 'reps', baseXp: 10 },
  { id: 'lateral', name: 'DB Lateral Raises', cue: 'Lead with elbows', baseTarget: 12, unit: 'reps', baseXp: 7 },
  { id: 'hammer', name: 'Hammer Curls', cue: 'Neutral grip', baseTarget: 10, unit: 'reps', baseXp: 8 },
  { id: 'floorpress', name: 'DB Floor Press', cue: 'Elbows stop at floor', baseTarget: 10, unit: 'reps', baseXp: 9 },
  { id: 'rdl', name: 'DB Romanian DL', cue: 'Hinge, soft knees', baseTarget: 10, unit: 'reps', baseXp: 9 },
  { id: 'thruster', name: 'DB Thrusters', cue: 'Drive through heels', baseTarget: 8, unit: 'reps', baseXp: 11 },
  { id: 'renegade', name: 'Renegade Rows', cue: 'Stable plank', baseTarget: 8, unit: 'reps', baseXp: 10 }
];

const RANKS = [
  { name: 'Spark', min: 0 },
  { name: 'Ember', min: 200 },
  { name: 'Flame', min: 600 },
  { name: 'Blaze', min: 1500 },
  { name: 'Inferno', min: 4000 },
  { name: 'Forge Master', min: 10000 }
];

const WEEK_TIERS = [
  { name: 'Starting', min: 0 },
  { name: 'Building', min: 40 },
  { name: 'Steady', min: 80 },
  { name: 'Strong', min: 140 },
  { name: 'Elite', min: 200 }
];

let state = loadState();
let circuit = null;
let restTimer = null;

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return {
    pace: 'steady',
    weight: 20,
    streak: 0,
    freezes: 0,
    points: 0,
    lastDate: null,
    today: {},
    targets: {},
    history: [],
    onboardingDone: false,
    dismissedExplainer: false,
    earnedFreezeAt: 0
  };
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function paceMult() {
  return { easy: 0.6, steady: 1, hard: 1.5 }[state.pace] || 1;
}

function getTarget(ex) {
  const base = state.targets[ex.id] ?? Math.round(ex.baseTarget * paceMult());
  return Math.max(1, base);
}

function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

function featuredDBs() {
  const d = new Date();
  const seed = d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate();
  const list = [...DUMBBELLS];
  // simple deterministic shuffle
  for (let i = list.length - 1; i > 0; i--) {
    const j = (seed * (i + 1)) % (i + 1);
    [list[i], list[j]] = [list[j], list[i]];
  }
  return list.slice(0, 3);
}

function getRank() {
  let r = RANKS[0];
  for (const rank of RANKS) if (state.points >= rank.min) r = rank;
  return r;
}

function getWeekTier() {
  // simple: points earned this week (last 7 days)
  const weekPts = state.history.filter(h => {
    const diff = (Date.now() - new Date(h.date).getTime()) / 86400000;
    return diff < 7;
  }).reduce((s, h) => s + (h.points || 0), 0) + (state.today.points || 0);
  let t = WEEK_TIERS[0];
  for (const tier of WEEK_TIERS) if (weekPts >= tier.min) t = tier;
  return t;
}

function checkSeal() {
  const coreDone = CORE.filter(ex => (state.today[ex.id] || 0) >= getTarget(ex)).length;
  const dbDone = featuredDBs().filter(ex => (state.today[ex.id] || 0) >= getTarget(ex)).length;
  const atTarget = coreDone + dbDone;
  const pts = state.today.points || 0;
  return atTarget >= 4 || pts >= 50;
}

function logSet(exId, amount = 1) {
  const key = todayKey();
  if (state.lastDate !== key) {
    // new day
    if (state.lastDate) {
      const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
      if (state.lastDate !== yesterday && state.freezes > 0) {
        state.freezes--;
        // streak preserved via freeze
      } else if (state.lastDate !== yesterday) {
        state.streak = 0;
      }
    }
    state.today = { points: 0 };
    state.lastDate = key;
  }
  state.today[exId] = (state.today[exId] || 0) + amount;
  const ex = [...CORE, ...DUMBBELLS].find(e => e.id === exId);
  const xp = Math.round(ex.baseXp * paceMult());
  state.today.points = (state.today.points || 0) + xp;
  state.points += xp;
  if (checkSeal() && !state.today.sealed) {
    state.today.sealed = true;
    state.streak++;
    state.today.points += 10; // seal bonus
    state.points += 10;
    // earn freeze every 7
    if (state.streak > 0 && state.streak % 7 === 0 && state.freezes < 2) {
      state.freezes++;
    }
  }
  saveState();
  render();
}

function buyFreeze() {
  if (state.points >= 70 && state.freezes < 2) {
    state.points -= 70;
    state.freezes++;
    saveState();
    render();
  }
}

function exportBackup() {
  const data = localStorage.getItem(STORAGE_KEY);
  const blob = new Blob([data], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'forge-backup.json';
  a.click();
}

function copyBackup() {
  navigator.clipboard.writeText(localStorage.getItem(STORAGE_KEY) || '{}');
  alert('Backup copied to clipboard');
}

function importBackup(file) {
  if (!confirm('Import will overwrite current data. Continue?')) return;
  const reader = new FileReader();
  reader.onload = e => {
    try {
      const data = JSON.parse(e.target.result);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
      state = loadState();
      render();
      alert('Imported');
    } catch {
      alert('Invalid backup');
    }
  };
  reader.readAsText(file);
}

function startCircuit() {
  const moves = [CORE[0], ...featuredDBs()]; // core then 3 DBs
  // for progress n/9: assume 3 sets core + 2 per DB = 3+6=9
  circuit = {
    moves,
    setIndex: 0,
    totalSets: 9,
    currentMove: 0,
    setsLeft: [3, 2, 2, 2]
  };
  render();
}

function logCircuitSet() {
  if (!circuit) return;
  const move = circuit.moves[circuit.currentMove];
  logSet(move.id, 1);
  circuit.setIndex++;
  circuit.setsLeft[circuit.currentMove]--;
  if (circuit.setsLeft[circuit.currentMove] <= 0) {
    circuit.currentMove++;
    if (circuit.currentMove >= circuit.moves.length) {
      circuit = null;
      return;
    }
  }
  startRest();
}

function startRest() {
  let secs = 45;
  const el = document.getElementById('rest-time');
  if (el) el.textContent = secs;
  if (restTimer) clearInterval(restTimer);
  restTimer = setInterval(() => {
    secs--;
    if (el) el.textContent = secs;
    if (secs <= 0) {
      clearInterval(restTimer);
      restTimer = null;
      render();
    }
  }, 1000);
}

function skipRest() {
  if (restTimer) {
    clearInterval(restTimer);
    restTimer = null;
  }
  render();
}

function render() {
  const app = document.getElementById('app');
  if (!state.onboardingDone) {
    app.innerHTML = onboardingHTML();
    return;
  }
  const tab = document.querySelector('.tab.active')?.dataset.tab || 'today';
  if (tab === 'today') {
    app.innerHTML = todayHTML();
  } else {
    app.innerHTML = youHTML();
  }
  bindEvents();
}

function onboardingHTML() {
  return `
    <div class="card">
      <h2 class="serif">Forge</h2>
      <p>Daily iron strength. Pick your pace and dumbbell weight.</p>
      <label>Pace</label>
      <select id="pace">
        <option value="easy">Easy (0.6×)</option>
        <option value="steady" selected>Steady (1×)</option>
        <option value="hard">Hard (1.5×)</option>
      </select>
      <label>Dumbbell weight (lbs)</label>
      <input type="number" id="weight" value="20" min="5" max="100">
      <button class="btn" id="start">Begin</button>
    </div>
  `;
}

function todayHTML() {
  const featured = featuredDBs();
  const sealed = checkSeal();
  const rank = getRank();
  const tier = getWeekTier();
  let html = '';
  if (!state.dismissedExplainer) {
    html += `<div class="explainer">
      Rank is lifetime points. Week tier is this week's score. Both climb with consistency.
      <button id="dismiss">×</button>
    </div>`;
  }
  html += `<div class="seal-status">
    <div class="seal-icon">${sealed ? '✓' : '○'}</div>
    <div>
      <div class="serif" style="font-size:1.3rem">Seal the day</div>
      <div style="color:var(--muted);font-size:0.85rem">${sealed ? 'Sealed · +10' : '4 at target or 50 pts'}</div>
    </div>
  </div>`;
  html += `<div>Streak ${state.streak} · Freezes ${state.freezes}/2 · ${rank.name}</div>`;
  if (circuit) {
    html += circuitHTML();
  } else {
    html += `<h3 class="serif">Core</h3>`;
    CORE.forEach(ex => html += exerciseCard(ex));
    html += `<h3 class="serif">Featured Dumbbells</h3>`;
    featured.forEach(ex => html += exerciseCard(ex));
    html += `<button class="btn secondary" id="show-all">Show all dumbbells</button>`;
    html += `<div id="all-dbs" class="hidden">`;
    DUMBBELLS.filter(d => !featured.includes(d)).forEach(ex => html += exerciseCard(ex));
    html += `</div>`;
    html += `<button class="btn" id="start-circuit">Start circuit</button>`;
  }
  return html;
}

function exerciseCard(ex) {
  const done = state.today[ex.id] || 0;
  const target = getTarget(ex);
  const pct = Math.min(100, (done / target) * 100);
  return `<div class="exercise" data-id="${ex.id}">
    <div class="ex-header">
      <span class="ex-name">${ex.name}</span>
      <span>${done}/${target} ${ex.unit}</span>
    </div>
    <div class="cue">${ex.cue}</div>
    <div class="progress-bar"><div class="progress-fill" style="width:${pct}%"></div></div>
    <div class="stepper">
      <button class="minus">−</button>
      <span>Target</span>
      <button class="plus">+</button>
    </div>
  </div>`;
}

function circuitHTML() {
  if (!circuit) return '';
  const move = circuit.moves[circuit.currentMove];
  const n = circuit.setIndex;
  return `<div class="circuit-view">
    <div class="progress-circuit">${n}/9</div>
    <div class="current-ex serif">${move.name}</div>
    <div class="cue">${move.cue}</div>
    ${restTimer ? `<div class="rest-timer"><div class="time" id="rest-time">45</div><button class="btn secondary" id="skip-rest">Skip rest</button></div>` :
      `<button class="btn large" id="log-set">Log</button>`}
  </div>`;
}

function youHTML() {
  const rank = getRank();
  const tier = getWeekTier();
  return `
    <div class="card">
      <h3 class="serif">You</h3>
      <p>Pace: ${state.pace} · Weight: ${state.weight} lb</p>
      <p>Points: ${state.points} · Rank: ${rank.name}</p>
      <p>Week tier: ${tier.name}</p>
      <details>
        <summary class="serif" style="cursor:pointer;margin:0.5rem 0">Daily targets</summary>
        ${[...CORE, ...DUMBBELLS].map(ex => `<div style="display:flex;justify-content:space-between;padding:0.3rem 0"><span>${ex.name}</span><span>${getTarget(ex)}</span></div>`).join('')}
      </details>
    </div>
    <div class="card">
      <h3 class="serif">Ranks</h3>
      ${RANKS.map(r => `<div class="ladder-item"><span>${r.name}</span><span>${r.min}+ pts</span></div>`).join('')}
    </div>
    <div class="card">
      <h3 class="serif">Week tiers</h3>
      ${WEEK_TIERS.map(t => `<div class="ladder-item"><span>${t.name}</span><span>${t.min}+ week pts</span></div>`).join('')}
    </div>
    <div class="card install-box">
      <h3 class="serif">Install</h3>
      <div id="install-area"></div>
    </div>
    <div class="card backup-box">
      <h3 class="serif">Backup</h3>
      <button class="btn secondary" id="export">Export JSON</button>
      <button class="btn secondary" id="copy">Copy backup</button>
      <input type="file" id="import" accept=".json" style="display:none">
      <button class="btn secondary" id="import-btn">Import</button>
    </div>
    <div class="card">
      <button class="btn secondary" id="buy-freeze">Buy freeze (70 pts)</button>
      <p style="font-size:0.85rem;color:var(--muted);margin-top:0.5rem">Max 2. Earn 1 every 7 streak days.</p>
    </div>
  `;
}

function bindEvents() {
  document.getElementById('start')?.addEventListener('click', () => {
    state.pace = document.getElementById('pace').value;
    state.weight = +document.getElementById('weight').value || 20;
    state.onboardingDone = true;
    saveState();
    render();
  });
  document.getElementById('dismiss')?.addEventListener('click', () => {
    state.dismissedExplainer = true;
    saveState();
    render();
  });
  document.getElementById('show-all')?.addEventListener('click', () => {
    document.getElementById('all-dbs').classList.toggle('hidden');
  });
  document.getElementById('start-circuit')?.addEventListener('click', startCircuit);
  document.getElementById('log-set')?.addEventListener('click', logCircuitSet);
  document.getElementById('skip-rest')?.addEventListener('click', skipRest);
  document.querySelectorAll('.plus').forEach(btn => {
    btn.addEventListener('click', e => {
      const id = e.target.closest('.exercise').dataset.id;
      const ex = [...CORE, ...DUMBBELLS].find(x => x.id === id);
      const cur = getTarget(ex);
      state.targets[id] = cur + 1;
      saveState();
      render();
    });
  });
  document.querySelectorAll('.minus').forEach(btn => {
    btn.addEventListener('click', e => {
      const id = e.target.closest('.exercise').dataset.id;
      const ex = [...CORE, ...DUMBBELLS].find(x => x.id === id);
      const cur = getTarget(ex);
      state.targets[id] = Math.max(1, cur - 1);
      saveState();
      render();
    });
  });
  document.getElementById('export')?.addEventListener('click', exportBackup);
  document.getElementById('copy')?.addEventListener('click', copyBackup);
  document.getElementById('import-btn')?.addEventListener('click', () => document.getElementById('import').click());
  document.getElementById('import')?.addEventListener('change', e => {
    if (e.target.files[0]) importBackup(e.target.files[0]);
  });
  document.getElementById('buy-freeze')?.addEventListener('click', buyFreeze);
  // install prompt handling
  setupInstall();
}

let deferredPrompt;
window.addEventListener('beforeinstallprompt', e => {
  e.preventDefault();
  deferredPrompt = e;
  setupInstall();
});

function setupInstall() {
  const area = document.getElementById('install-area');
  if (!area) return;
  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
  const isStandalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone;
  if (isStandalone) {
    area.innerHTML = '<p>Already installed</p>';
    return;
  }
  if (deferredPrompt) {
    area.innerHTML = '<button class="btn" id="install-btn">Install Forge</button>';
    document.getElementById('install-btn').onclick = async () => {
      deferredPrompt.prompt();
      await deferredPrompt.userChoice;
      deferredPrompt = null;
      setupInstall();
    };
  } else if (isIOS) {
    area.innerHTML = '<p>Share → Add to Home Screen</p>';
  } else {
    area.innerHTML = '<p>Chrome/Edge menu → Install app / Add to Home Screen</p>';
  }
}

document.addEventListener('DOMContentLoaded', () => {
  render();
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      render();
    });
  });
});

// service worker registration
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js');
}